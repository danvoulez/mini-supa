#!/bin/bash
set -euo pipefail

echo "==> Iniciando instalação institucional do FlipApp..."

# Validar comandos essenciais
for cmd in python3 npm git; do
  if ! command -v $cmd &> /dev/null; then
    echo "ERRO: $cmd não encontrado. Instale antes de continuar."
    exit 1
  fi
done

# Criar virtualenv
if [ ! -d "venv" ]; then
  python3 -m venv venv
fi

source venv/bin/activate
pip install -U pip wheel
pip install -r requirements.txt || echo "requirements.txt não encontrado, prosseguindo com instalação leve"

# Setup frontend
cd frontend
npm install
npm run build || echo "Build inicial falhou, pode não haver frontend ainda"
cd ..

# Diretórios para logs
mkdir -p /var/log/institutional/{pending,signed,archive}
chmod 755 /var/log/institutional

echo "==> Instalação completa. Execute 'make deploy' para subir o sistema."
