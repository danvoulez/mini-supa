import { serve } from "https://deno.land/std@0.178.0/http/server.ts";

serve(async (req) => {
  if (req.method !== "GET") {
    return new Response("Método não permitido", { status: 405 });
  }

  const GITHUB_TOKEN = Deno.env.get("GITHUB_TRIGGER_TOKEN");
  if (!GITHUB_TOKEN) {
    return new Response("Token não configurado", { status: 500 });
  }

  try {
    const res = await fetch(
      "https://api.github.com/repos/USER/REPO/actions/workflows/deploy-supabase.yml/dispatches",
      {
        method: "POST",
        headers: {
          "Accept": "application/vnd.github+json",
          "Authorization": `Bearer ${GITHUB_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ref: "main",
          inputs: { environment: "production" },
        }),
      }
    );

    if (!res.ok) {
      const text = await res.text();
      return new Response(`Erro GitHub API: ${res.status}\n${text}`, { status: res.status });
    }

    return new Response("✅ Deploy iniciado!", { status: 200 });
  } catch (err) {
    return new Response(`⚠️ Exceção: ${err}`, { status: 500 });
  }
});
