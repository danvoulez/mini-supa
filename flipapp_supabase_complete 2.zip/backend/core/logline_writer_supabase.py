import os
import requests
import logging

SUPABASE_URL = os.getenv('SUPABASE_URL')
SERVICE_ROLE_KEY = os.getenv('SUPABASE_SERVICE_ROLE_KEY')
ENDPOINT = f"{SUPABASE_URL}/rest/v1/logline"

HEADERS = {
    "apikey": SERVICE_ROLE_KEY,
    "Authorization": f"Bearer {SERVICE_ROLE_KEY}",
    "Content-Type": "application/json"
}

def write_log(log_dict: dict) -> dict:
    try:
        resp = requests.post(ENDPOINT, json=log_dict, headers=HEADERS)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        logging.warning(f"[write_log] failed: {e}")
        raise

if __name__ == "__main__":
    sample = {"who": "user_example", "did": "Test Supabase"}
    try:
        result = write_log(sample)
        print("Inserted:", result)
    except Exception:
        print("Error writing log.")
