import json
from pathlib import Path
import hashlib
from datetime import datetime
from typing import Dict, Optional
import threading

class LogLineWriter:
    def __init__(self, base_path: str = "/var/log/institutional"):
        self.log_dir = Path(base_path)
        self.lock = threading.Lock()
        self.ensure_directories()

    def ensure_directories(self):
        self.log_dir.mkdir(parents=True, exist_ok=True)
        (self.log_dir / "pending").mkdir(exist_ok=True)
        (self.log_dir / "signed").mkdir(exist_ok=True)

    def _file_for_tenant(self, tenant_id: str) -> Path:
        date_str = datetime.utcnow().strftime("%Y-%m-%d")
        return self.log_dir / "pending" / f"{tenant_id}_{date_str}.jsonl"

    @staticmethod
    def compute_institutional_hash(payload: Dict) -> str:
        sorted_payload = json.dumps(payload, sort_keys=True, separators=(',', ':'))
        return hashlib.sha3_256(sorted_payload.encode()).hexdigest()

    def write(self, event_type: str, entity_id: str, payload: Dict, tenant_id: str) -> Dict:
        with self.lock:
            log_entry = {
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "eventType": event_type,
                "entityId": entity_id,
                "payload": payload,
                "tenantId": tenant_id,
                "chainHash": self.compute_institutional_hash(payload)
            }
            target_file = self._file_for_tenant(tenant_id)
            with target_file.open('a') as f:
                f.write(json.dumps(log_entry) + '\n')
            return log_entry

logline_writer = LogLineWriter()
