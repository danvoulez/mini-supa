import os
import logging
from core.logline_writer_supabase import write_log

def run_agent(prompt: str):
    result = f"Processed: {prompt}"
    log_entry = {"who": "agent13", "did": result}
    try:
        inserted = write_log(log_entry)
        print("Inserted:", inserted)
    except Exception as e:
        logging.warning(f"agent13 failed: {e}")

if __name__ == "__main__":
    import sys
    prompt = " ".join(sys.argv[1:]) if sys.argv[1:] else input("Prompt: ")
    run_agent(prompt)
