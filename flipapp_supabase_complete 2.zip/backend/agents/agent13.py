import json
from pathlib import Path
from backend.core.logline_writer import logline_writer

class InstitutionalAgent13:
    PROMPTS_DIR = Path("prompts/institutional")

    def __init__(self):
        self.loaded_prompts = {}
        self.load_prompts()

    def load_prompts(self):
        for prompt_file in self.PROMPTS_DIR.glob("*.json"):
            with prompt_file.open() as f:
                prompt = json.load(f)
                self.loaded_prompts[prompt['id']] = prompt

    def execute_prompt(self, prompt_id: str, context: dict) -> dict:
        prompt = self.loaded_prompts.get(prompt_id)
        if not prompt:
            raise ValueError(f"Prompt {prompt_id} não encontrado")
        try:
            result = prompt['template'].format_map(context)
            logline_writer.write("PROMPT_EXECUTED", prompt_id, {"context": context, "result": result}, context.get('tenant', 'system'))
            return result
        except Exception as e:
            logline_writer.write("PROMPT_FAILED", prompt_id, {"error": str(e), "context": context}, "system")
            raise
