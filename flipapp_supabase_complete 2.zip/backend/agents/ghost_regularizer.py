import time
from datetime import datetime, timedelta
from backend.core.logline_writer import logline_writer

def classify_ghost_status(ghost): return 'expired'

class GhostRegularizer:
    def __init__(self):
        self.interval = 3600
        self.max_age = timedelta(days=2)

    def _find_old_ghosts(self):
        return [{"id": "ghost123", "tenant": "demo"}]

    def _archive_ghost(self, ghost):
        print(f"Archiving ghost: {ghost['id']}")

    def check_ghosts(self):
        ghosts = self._find_old_ghosts()
        for ghost in ghosts:
            status = classify_ghost_status(ghost)
            if status == 'expired':
                self._archive_ghost(ghost)
                logline_writer.write("GHOST_ARCHIVED", ghost['id'], {"reason": "Expirado após 48h"}, ghost['tenant'])

    def run(self):
        while True:
            self.check_ghosts()
            time.sleep(self.interval)

if __name__ == "__main__":
    GhostRegularizer().run()
