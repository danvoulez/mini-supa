import os
import requests
import logging

SUPABASE_URL = os.getenv('SUPABASE_URL')
SERVICE_ROLE_KEY = os.getenv('SUPABASE_SERVICE_ROLE_KEY')
ENDPOINT = f"{SUPABASE_URL}/rest/v1/logline"

HEADERS = {
    "apikey": SERVICE_ROLE_KEY,
    "Authorization": f"Bearer {SERVICE_ROLE_KEY}",
    "Content-Type": "application/json"
}

def fetch_invalid_logs():
    params = {"valid": "eq.false", "select": "id"}
    try:
        resp = requests.get(ENDPOINT, headers=HEADERS, params=params)
        resp.raise_for_status()
        return resp.json()
    except requests.RequestException as e:
        logging.warning(f"fetch_invalid_logs failed: {e}")
        return []

def archive_log(log_id: int):
    try:
        resp = requests.patch(
            ENDPOINT,
            headers=HEADERS,
            params={"id": f"eq.{log_id}"},
            json={"archived": True}
        )
        resp.raise_for_status()
        return True
    except requests.RequestException as e:
        logging.warning(f"archive_log {log_id} failed: {e}")
        return False

if __name__ == "__main__":
    logs = fetch_invalid_logs()
    for log in logs:
        lid = log.get("id")
        if lid:
            print("Archived:", lid, archive_log(lid))
