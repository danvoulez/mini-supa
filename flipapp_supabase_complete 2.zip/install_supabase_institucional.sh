#!/usr/bin/env bash
set -euo pipefail

# Load .env or .env.example
if [[ -f .env ]]; then
  export $(grep -v '^\s*#' .env | xargs)
elif [[ -f .env.example ]]; then
  cp .env.example .env
  export $(grep -v '^\s*#' .env | xargs)
else
  echo "❌ .env not found"
  exit 1
fi

# Install Supabase CLI
if ! command -v supabase &> /dev/null; then
  if [[ "$(uname)" == "Darwin" ]]; then
    brew install supabase/tap/supabase
  else
    curl -fsSL https://github.com/supabase/cli/releases/latest/download/supabase_linux_amd64.tar.gz     | tar xz supabase && mv supabase /usr/local/bin/
  fi
fi

# Supabase link and push
supabase login --service-role-key "$SUPABASE_SERVICE_ROLE_KEY"
supabase link --project-ref "$SUPABASE_PROJECT_REF"
supabase db push --skip-generate-types
supabase gen types typescript --schema public --out-dir frontend/src/lib/supabase/types

# Dependencies
npm --prefix frontend install
pip install --user -r requirements.txt

# Test
python backend/core/logline_writer_supabase.py --test
python backend/agents/ghost_regularizer_supabase.py

echo "✅ Supabase setup complete"
