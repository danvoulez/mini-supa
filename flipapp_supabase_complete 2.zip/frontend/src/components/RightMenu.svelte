<!-- RightMenu.svelte -->
<script lang="ts">
  import LogPanel from './RightMenu/LogPanel.svelte';
  import GhostPanel from './RightMenu/GhostPanel.svelte';
  import IdlePanel from './RightMenu/IdlePanel.svelte';
  import { institutional } from '$lib/stores';

  $: log = $institutional.selectedLog;
  $: ghosts = $institutional.ghosts || [];
  $: draft = $institutional.currentDraft;
</script>

{#if log}
  <LogPanel />
{:else if ghosts.length > 0}
  <GhostPanel />
{:else}
  <IdlePanel />
{/if}
