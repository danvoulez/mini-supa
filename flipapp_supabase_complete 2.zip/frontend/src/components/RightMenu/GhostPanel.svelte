<!-- GhostPanel.svelte -->
<script lang="ts">
  import { institutional } from '$lib/stores';
  import { submitWithSignature } from '$lib/institutional';

  const regularizeNow = async () => {
    const response = await fetch('/ghost/regularize_now', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ trigger: 'manual' })
    });

    if (response.ok) {
      await submitWithSignature({
        who: $institutional.activeUser,
        did: "trigger-ghost-regularization",
        this: "manual cleanup",
        status: "executed"
      });
    }
  };
</script>

<div class="haptic-panel bg-institutional-gray-100">
  <div class="text-sm mb-4">🔄 Pendências fantasma</div>
  <button on:tap={regularizeNow} class="institutional-button">
    Ciclar Existências
  </button>
</div>
