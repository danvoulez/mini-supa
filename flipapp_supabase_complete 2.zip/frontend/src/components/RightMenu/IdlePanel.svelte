<!-- IdlePanel.svelte -->
<script lang="ts">
  import { onMount } from 'svelte';
  let currentSymbol = 0;
  const symbols = ['⬡', '⬢', '⬣', '⬤'];
  let timer;

  onMount(() => {
    timer = setInterval(() => {
      currentSymbol = (currentSymbol + 1) % symbols.length;
    }, 5000);
    return () => clearInterval(timer);
  });
</script>

<div class="haptic-panel bg-institutional-gray-50 opacity-75">
  <div class="text-4xl text-center">{symbols[currentSymbol]}</div>
</div>
