<!-- LogPanel.svelte -->
<script lang="ts">
  import { institutional } from '$lib/stores';
  import { submitWithSignature } from '$lib/institutional';

  let logDetails = {
    resolution: '',
    method: 'touch' as 'touch'|'gesture'|'force'
  };

  const resolveLog = async (status: 'confirmed'|'doubt'|'rejected') => {
    await submitWithSignature({
      who: $institutional.activeUser,
      did: `resolve-with-${logDetails.method}`,
      this: `log ${$institutional.selectedLog?.id} as ${status}`,
      status: 'pending'
    });
  };
</script>

<div class="haptic-panel bg-institutional-blue-50">
  <div class="grid grid-cols-3 gap-2 mb-4">
    <button on:tap={() => logDetails.method = 'touch'} class:active={logDetails.method === 'touch'}>
      ✋
    </button>
    <button on:tap={() => logDetails.method = 'gesture'} class:active={logDetails.method === 'gesture'}>
      ↪️
    </button>
    <button on:tap={() => logDetails.method = 'force'} class:active={logDetails.method === 'force'}>
      ⚡
    </button>
  </div>

  <input type="text" bind:value={logDetails.resolution} 
         class="institutional-input" placeholder="Assinatura tátil" />

  <div class="flex gap-2 mt-4">
    <button on:tap={() => resolveLog('confirmed')} class="success-button">✅</button>
    <button on:tap={() => resolveLog('doubt')} class="warning-button">⁉️</button>
    <button on:tap={() => resolveLog('rejected')} class="danger-button">🚫</button>
  </div>
</div>

<style>
  .haptic-panel {
    padding: 1rem;
    border-radius: 0.5rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  }

  button.active {
    background-color: #e0f2fe;
  }
</style>
