<!-- LeftMenu.svelte -->
<script lang="ts">
  import { goto } from '$app/navigation';
  import { institutional } from '$lib/stores';
</script>

<div class="w-14 h-screen bg-[#f0f4f8] border-r border-gray-200 flex flex-col justify-between">
  <!-- Bloco Superior - Aplicações Principais -->
  <div class="flex flex-col space-y-4 p-2">
    <button
      on:click={() => goto('/timeline')}
      class="w-10 h-10 flex items-center justify-center rounded hover:bg-gray-200/50 transition-colors"
    >
      🧭
    </button>

    <button
      on:click={() => goto('/communicator')}
      class="w-10 h-10 flex items-center justify-center rounded hover:bg-gray-200/50 transition-colors"
    >
      💬
    </button>

    <button
      on:click={() => goto('/new')}
      class="w-10 h-10 flex items-center justify-center rounded hover:bg-gray-200/50 transition-colors"
    >
      ➕
    </button>
  </div>

  <!-- Bloco Inferior - Identidade e Configurações -->
  <div class="flex flex-col space-y-4 p-2">
    <button
      on:click={() => goto('/me')}
      class="w-10 h-10 flex items-center justify-center rounded hover:bg-gray-200/50 transition-colors"
    >
      {$institutional.isInstitutional ? '🏢' : '🧍'}
    </button>

    <button
      on:click={() => goto('/settings')}
      class="w-10 h-10 flex items-center justify-center rounded hover:bg-gray-200/50 transition-colors"
    >
      ⚙️
    </button>
  </div>
</div>

<style global>
  button {
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 1.5rem;
    line-height: 1;
  }
</style>
